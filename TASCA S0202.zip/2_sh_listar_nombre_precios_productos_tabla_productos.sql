USE tienda;

SELECT
p.nombre,
p.precio
FROM
producto p