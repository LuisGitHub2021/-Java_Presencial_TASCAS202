SELECT 

f.nombre,
upper(left(f.nombre,2))

FROM
fabricante f


