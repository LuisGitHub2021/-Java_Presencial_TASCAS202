USE tienda;

SELECT 
p.nombre
FROM
producto p