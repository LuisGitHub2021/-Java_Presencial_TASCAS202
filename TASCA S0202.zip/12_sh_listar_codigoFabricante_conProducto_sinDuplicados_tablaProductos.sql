USE tienda;

SELECT distinct

p.codigo_fabricante

FROM producto p
