USE tienda;

SELECT
p.nombre,
round(p.precio)

FROM 
producto p