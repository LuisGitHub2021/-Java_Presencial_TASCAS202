USE tienda;

SELECT

p.codigo_fabricante

FROM producto p

