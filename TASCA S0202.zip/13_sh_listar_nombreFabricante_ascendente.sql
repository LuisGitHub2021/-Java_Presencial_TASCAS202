USE tienda;

SELECT

f.nombre

FROM fabricante f
ORDER BY f.nombre